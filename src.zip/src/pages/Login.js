import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Login.css";

const Login = () => {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const [feedback, setFeedback] = useState(""); // User feedback messages
  const [loading, setLoading] = useState(false); // Button loading state
  const navigate = useNavigate();

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setFeedback(""); // Reset feedback

    // Form validation
    if (!formData.email || !formData.password) {
      setFeedback("❌ Email and password are required.");
      setLoading(false);
      return;
    }

    try {
      const response = await fetch("http://localhost:5000/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      const result = await response.json();
      setLoading(false);

      if (response.ok) {
        setFeedback("✅ Login successful! Redirecting...");
        // Save user data (like user_id) to localStorage or sessionStorage (optional)
        sessionStorage.setItem("user_id", result.user_id);  // Store user_id in sessionStorage

        // Redirect to the dashboard after 2 seconds
        setTimeout(() => navigate("/dashboard"), 2000);
      } else {
        setFeedback(`❌ ${result.message}`);
      }
    } catch (error) {
      console.error("Error during login:", error);
      setFeedback("❌ Error during login. Please try again.");
      setLoading(false);
    }
  };

  return (
    <div className="login-container">
      <div className="login-box">
        <h2>🔐 Login to Your Account</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>📧 Email</label>
            <input
              type="text"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              placeholder="Enter email."
            />
          </div>

          <div className="form-group">
            <label>🔒 Password</label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              required
              placeholder="Enter your password"
            />
          </div>

          <button type="submit" className="login-btn" disabled={loading}>
            {loading ? (
              <>
                <span className="spinner"></span> Logging in...
              </>
            ) : (
              "Login"
            )}
          </button>
          {feedback && <p className="feedback">{feedback}</p>}

          <p className="signup-link">
            Don't have an account? <Link to="/signup">Sign up here</Link>
          </p>
        </form>
      </div>
    </div>
  );
};

export default Login;
