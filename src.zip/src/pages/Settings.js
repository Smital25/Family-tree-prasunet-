import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./Settings.css";

const Settings = () => {
  const [profile, setProfile] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
  });
 
  const [showDeletePopup, setShowDeletePopup] = useState(false);

  const navigate = useNavigate();
  const username = localStorage.getItem("username");

  useEffect(() => {
    // Fetch user data
    fetch(`http://localhost:5000/api/get-user/${username}`)
      .then((res) => res.json())
      .then((data) => setProfile(data))
      .catch((err) => console.error(err));
  }, [username]);

  const handleProfileChange = (e) => {
    const { name, value } = e.target;
    setProfile({ ...profile, [name]: value });
  };


  const saveSettings = async () => {
    await fetch("http://localhost:5000/api/update-profile", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(profile),
    });
    alert("✅ Profile updated successfully!");
  };

  const deleteAccount = async () => {
    await fetch(`http://localhost:5000/api/delete-user/${username}`, {
      method: "DELETE",
    });
    alert("❌ Account deleted");
    localStorage.clear();
    navigate("/");
  };

  return (
    <div className="settings-container">
      <h2>⚙️ Settings</h2>

      <div className="settings-section">
        <h3>👤 Profile</h3>
        <input name="name" value={profile.name} onChange={handleProfileChange} placeholder="Name" />
        <input name="email" value={profile.email} onChange={handleProfileChange} placeholder="Email" />
        <input name="phone" value={profile.phone} onChange={handleProfileChange} placeholder="Phone" />
        <input name="address" value={profile.address} onChange={handleProfileChange} placeholder="Address" />
        <button className="save-btn" onClick={saveSettings}>💾 Save Changes</button>
      </div>



      <div className="settings-section">
        <h3>🔐 Danger Zone</h3>
        <button className="delete-btn" onClick={() => setShowDeletePopup(true)}>❌ Delete Account</button>
      </div>
      
    

      <button className="back-btn" onClick={() => window.location.href = "/dashboard"}>
          🔙 Back to Dashboard
      </button>


      {showDeletePopup && (
        <div className="delete-popup">
          <p>Are you sure you want to delete your account?</p>
          <button onClick={() => setShowDeletePopup(false)}>Cancel</button>
          <button className="confirm-btn" onClick={deleteAccount}>Yes, Delete</button>
        </div>
      )}
    </div>
  );
};

export default Settings;
