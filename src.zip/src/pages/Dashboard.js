import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { FiSearch, FiLogOut } from "react-icons/fi";
import { FaUsers, FaCameraRetro, FaSitemap } from "react-icons/fa";
import "./Dashboard.css";
import addmembers from '../assets/add-member.jpg';
import memories from '../assets/memories.jpg';
import familytree from '../assets/family-tree.webp';
import tsetp1 from '../assets/tstep1.jpg';
import tstep2 from '../assets/tstep2.jpg';
import tsetp3 from '../assets/tstep3.jpg';
const Dashboard = () => {
  const [userData, setUserData] = useState(null);
  const [stats, setStats] = useState({});
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const navigate = useNavigate();

  useEffect(() => {
    const userId = sessionStorage.getItem("user_id");
    if (!userId) {
      navigate("/login");
      return;
    }

    const fetchData = async () => {
      try {
        const res = await fetch(`http://localhost:5000/dashboard/${userId}`);
        const data = await res.json();
        if (res.ok) {
          setUserData(data.user);
          setStats(data.stats || {});
        } else {
          setError(data.message || "Failed to fetch dashboard data.");
        }
      } catch (err) {
        setError("Something went wrong.");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [navigate]);

  const handleLogout = () => {
    sessionStorage.removeItem("user_id");
    navigate("/");
  };

  if (loading) return <div className="loading-screen">Loading...</div>;
  if (error) return <div className="error-screen">{error}</div>;

  return (
    <div className="dashboard-container">
      {/* Header */}
      <div className="dashboard-header">
      <div className="user-info">
        <div>
          <h2>Welcome, {userData.username}</h2>
          <p>{userData.email}</p>
        </div>
      </div>
        <div className="dashboard-actions">
          <div className="search-wrapper">
            <FiSearch className="search-icon" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search Family Members..."
            />
          </div>
          <button className="logout-btn" onClick={handleLogout}>
            <FiLogOut size={18} /> Logout
          </button>
        </div>
      </div>

      {/* Description */}
      <p className="search-tip">
        Use smart search to quickly find members by name, relation, or event.
      </p>

      {/* Stats */}
      <div className="stats-grid">
        <div className="stat-card">
          <FaUsers className="stat-icon" />
          <div>
            <h4>Family Members</h4>
            <p>{stats.familyMembers}</p>
          </div>
        </div>
        <div className="stat-card">
          <FaCameraRetro className="stat-icon" />
          <div>
            <h4>Memories</h4>
            <p>{stats.memories}</p>
          </div>
        </div>
        <div className="stat-card">
          <FaSitemap className="stat-icon" />
          <div>
            <h4>Tree Nodes</h4>
            <p>{stats.familyTreeSize}</p>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="features-section">
        <div className="feature-card" onClick={() => navigate("/add-member")}>
        <img src={addmembers} alt="add-member" />
          <h4>Add New Member</h4>
        </div>
        <div className="feature-card" onClick={() => navigate("/memories")}>
        <img src={memories} alt="memories" />
          <h4>View Memories</h4>
        </div>
        <div className="feature-card" onClick={() => navigate("/family-tree")}>
        <img src={familytree} alt="family-tree" />
          <h4>Family Tree</h4>
        </div>
      </div>


      {/* How It Works - Family Tree Legacy */}
      <div className="family-tree-steps">
        <h3>How the Family Tree Works</h3>
        <div className="step-card">
          <img src={tsetp1} alt="family-tree" />
          <h4>Step 1: Add Your Family Members</h4>
          <p>
            Start by adding the essential members of your family with their
            details and relationships. This helps you begin building your
            family legacy.
          </p>
        </div>
        <div className="step-card">
        <img src={tstep2} alt="family-tree" />
          <h4>Step 2: Connect the Dots</h4>
          <p>
            Link the family members together to establish connections, showing
            how everyone is related in your family tree.
          </p>
        </div>
        <div className="step-card">
        <img src={tsetp3} alt="family-tree" />
          <h4>Step 3: Share and Preserve</h4>
          <p>
            Share the family tree with others and preserve memories and stories
            for future generations to enjoy.
          </p>
        </div>
        </div>
    </div>
  );
};

export default Dashboard;
