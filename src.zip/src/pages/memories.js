import React, { useState, useEffect } from "react";
import "./Memories.css";

const Memories = () => {
  const [memories, setMemories] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedFile, setSelectedFile] = useState(null);
  const [location, setLocation] = useState("");
  const [comment, setComment] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [userId] = useState("USER123");  // Replace with actual logged-in user ID.
  const [familyId] = useState("FAM123");

  useEffect(() => {
    fetch(`http://localhost:5000/api/get-memories/${userId}`)
      .then(res => res.json())
      .then(data => setMemories(data))
      .catch(err => console.error("Error fetching memories:", err));
  }, [userId]);
  

  const convertToBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const handleFileChange = async (event) => {
    const file = event.target.files[0];
    if (file) {
      setSelectedFile(file);
      setIsModalOpen(true);
    }
  };

  const handleMemorySubmit = async () => {
    if (!selectedFile || !location || !comment) {
      alert("Please fill in all details.");
      return;
    }

    const base64Image = await convertToBase64(selectedFile);

    const memoryData = {
      user_id: userId,  // Ensure you're passing the user_id here
      family_id: familyId,
      image_base64: base64Image,
      location,
      comment,
      date: new Date().toLocaleDateString(),
    };

    console.log("Memory Data to submit:", memoryData); // Log for debugging

    fetch("http://localhost:5000/api/add-memory", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(memoryData),
    })
      .then((res) => res.json())
      .then((data) => {
        setMemories([...memories, { ...memoryData, _id: data.id }]);
        setLocation("");
        setComment("");
        setSelectedFile(null);
        setIsModalOpen(false);
      })
      .catch((err) => console.error("Error adding memory:", err));
  };

  const handleDelete = (id) => {
    console.log("Memory ID to delete:", id); // Log the ID for debugging

    if (!id) {
      console.error("Memory ID is missing");
      return;
    }

    fetch(`http://localhost:5000/api/delete-memory/${id}?user_id=${userId}`, {
      method: "DELETE",
    })
    
      .then((res) => res.json())
      .then(() => {
        setMemories(memories.filter((m) => m._id !== id));
      })
      .catch((err) => console.error("Error deleting memory:", err));
  };

  const filteredMemories = memories.filter((m) =>
    m.comment.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="memories-container">
      <div className="back-dashboard-btn">
        <button onClick={() => window.location.href = "/dashboard"}>🔙 Back to Dashboard</button>
      </div>

      <h2>📸 Family Memories</h2>
      <p className="sub-text">Capture and cherish your family's best moments forever.</p>

      {/* Upload Section */}
      <div className="upload-section">
        <label htmlFor="file-upload" className="custom-file-upload">📤 Upload Memory</label>
        <input id="file-upload" type="file" accept="image/*" onChange={handleFileChange} />
      </div>

      {/* Search */}
      <input
        type="text"
        className="search-bar"
        placeholder="🔍 Search memories by their names and comments..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />

      {/* Gallery */}
      <div className="memories-gallery">
        {filteredMemories.length > 0 ? (
          filteredMemories.map((memory) => (
            <div key={memory._id} className="memory-card">
              <img src={memory.image_base64} alt="Memory" />
              <div className="memory-info">
                <p>📅 {memory.date} | 📍 {memory.location}</p>
                <p className="comment">💬 {memory.comment}</p>
                <button className="delete-btn" onClick={() => handleDelete(memory._id)}>❌ Delete</button>
              </div>
            </div>
          ))
        ) : (
          <p className="no-memories">No memories found. Start by uploading your favorite moments! 😊</p>
        )}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="modal-overlay">
          <div className="modal-content">
            <h3>🖼️ Add Memory Details</h3>
            <img src={URL.createObjectURL(selectedFile)} alt="Preview" className="preview-img" />
            <input
              type="text"
              placeholder="📍 Enter Location"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            />
            <textarea
              placeholder="💬 Add a comment"
              value={comment}
              onChange={(e) => setComment(e.target.value)}
            />
            <button className="save-btn" onClick={handleMemorySubmit}>✅ Save Memory</button>
            <button className="cancel-btn" onClick={() => setIsModalOpen(false)}>❌ Cancel</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Memories;
