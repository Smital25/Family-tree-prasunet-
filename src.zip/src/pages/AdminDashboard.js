import React, { useEffect, useState } from "react";
import "./AdminDashboard.css";

const AdminDashboard = () => {
  const [stats, setStats] = useState({});
  const [users, setUsers] = useState([]);
  const [members, setMembers] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/admin/stats")
      .then(res => res.json())
      .then(data => {
        setStats(data);
        setUsers(data.users || []);
        setMembers(data.members || []);
      });
  }, []);

  return (
    <div className="admin-dashboard">
      <div className="admin-header">
        <h2>👑 Admin Dashboard</h2>
        <button className="logout-btn" onClick={() => window.location.href = "/"}>Logout</button>
      </div>

      <div className="admin-stats">
        <div className="stat-card"><h3>Total Users</h3><p>{stats.user_count}</p></div>
        <div className="stat-card"><h3>Family Members</h3><p>{stats.member_count}</p></div>
        <div className="stat-card"><h3>Memories</h3><p>{stats.memory_count}</p></div>
      </div>

      <div className="lists">
        <div className="list-section">
          <h3>👤 Users List</h3>
          <ul>
            {users.map((user, i) => (
              <li key={i}>{user.username} - {user.email}</li>
            ))}
          </ul>
        </div>

        <div className="list-section">
          <h3>👪 Members List</h3>
          <ul>
            {members.map((m, i) => (
              <li key={i}>{m.name} ({m.relation}) - Family ID: {m.family_id}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
