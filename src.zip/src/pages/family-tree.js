import React from "react";
import { useQuery } from "react-query";
import axios from "axios";

const fetchFamilyTree = async (familyId) => {
  const response = await axios.get(`/api/get-family-tree?family_id=${familyId}`);
  return response.data.family_tree;
};

const FamilyTree = ({ familyId }) => {
  const { data, error, isLoading } = useQuery(["familyTree", familyId], () => fetchFamilyTree(familyId));

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error fetching family tree</div>;
  }

  return (
    <div>
      <h2>Family Tree</h2>
      <ul>
        {data.map((member) => (
          <li key={member._id}>
            <div>
              <img src={`/uploads/${member.photo}`} alt={member.name} width={50} />
              <strong>{member.name}</strong> - {member.relation}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default FamilyTree;
