from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from pymongo import MongoClient
from werkzeug.utils import secure_filename
from bson import ObjectId
import hashlib
import os

app = Flask(__name__)
CORS(app)

# ------------------------- CONFIG -------------------------

UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# MongoDB setup
client = MongoClient("mongodb://localhost:27017/")
db = client["family_tree"]
users_collection = db["users"]
members_collection = db["members"]
memories_collection = db["memories"]

# ------------------------- HELPERS -------------------------

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def verify_password(stored_hash, password):
    return stored_hash == hash_password(password)

def save_image(photo):
    filename = secure_filename(photo.filename)
    path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    photo.save(path)
    return filename

# ------------------------- AUTH ROUTES -------------------------

@app.route("/signup", methods=["POST"])
def signup():
    form = request.form
    photo = request.files.get("photo")

    email = form.get("email")
    username = form.get("username")
    password = form.get("password")

    if not all([email, username, password]):
        return jsonify({"message": "Email, username, and password are required."}), 400

    if users_collection.find_one({"email": email}):
        return jsonify({"message": "User already exists!"}), 400

    photo_url = ""
    if photo:
        ext = photo.filename.split('.')[-1].lower()
        if ext not in ['jpg', 'jpeg', 'png']:
            return jsonify({"message": "❌ Invalid file type!"}), 400
        photo_url = save_image(photo)

    user_data = {
        "familyId": form.get("familyId"),
        "name": form.get("name"),
        "contact": form.get("contact"),
        "age": form.get("age"),
        "email": email,
        "dob": form.get("dob"),
        "gender": form.get("gender"),
        "address": form.get("address"),
        "username": username,
        "password": hash_password(password),
        "photo": photo_url,
    }

    users_collection.insert_one(user_data)
    return jsonify({"message": "✅ User registered successfully!"}), 201


@app.route("/login", methods=["POST"])
def login():
    data = request.json
    email = data.get("email")
    password = data.get("password")

    if not email or not password:
        return jsonify({"message": "Email and password are required."}), 400

    user = users_collection.find_one({"email": email})
    if user and verify_password(user["password"], password):
        return jsonify({
            "message": "✅ Login successful!",
            "user_id": str(user["_id"]),
            "familyId": user.get("familyId", "")
        }), 200
    return jsonify({"message": "❌ Invalid credentials"}), 401

@app.route("/logout", methods=["POST"])
def logout():
    return jsonify({"message": "✅ Logged out successfully"}), 200

# ------------------------- DASHBOARD -------------------------

@app.route("/dashboard/<user_id>", methods=["GET"])
def dashboard(user_id):
    try:
        user = users_collection.find_one({"_id": ObjectId(user_id)})
        if not user:
            return jsonify({"message": "❌ User not found"}), 404

        family_members_count = members_collection.count_documents({"family_id": user["familyId"]})
        memories_count = memories_collection.count_documents({"user_id": user_id})

        return jsonify({
            "user": {
                "username": user.get("username", ""),
                "email": user.get("email", ""),
                "photo": user.get("photo", ""),
            },
            "stats": {
                "familyMembers": family_members_count,
                "memories": memories_count,
                "familyTreeSize": family_members_count,  # same as familyMembers for now
            }
        }), 200
    except Exception as e:
        return jsonify({"message": f"❌ Error: {str(e)}"}), 500

# ------------------------- MEMBERS -------------------------

@app.route("/api/add-member", methods=["POST"])
def add_member():
    try:
        data = request.form
        photo = request.files.get("photo")
        filename = save_image(photo) if photo else None

        member = {
            "name": data["name"],
            "age": data["age"],
            "dob": data["dob"],
            "relation": data["relation"],
            "related_to": data["related_to"],
            "family_id": data["familyId"],
            "username": data["username"],
            "photo": filename
        }

        members_collection.insert_one(member)
        return jsonify({"message": "✅ Member added successfully"}), 200
    except Exception as e:
        return jsonify({"message": f"❌ Error: {str(e)}"}), 500

# Helper function to convert MongoDB's ObjectId to string
def serialize_member(member):
    member["_id"] = str(member["_id"])  # Convert ObjectId to string
    return member

@app.route("/api/get-family-tree", methods=["GET"])
def get_family_tree():
    family_id = request.args.get("family_id")

    if not family_id:
        return jsonify({"error": "Family ID is required"}), 400

    family_members = list(members_collection.find({"family_id": family_id}))
    
    # Serialize each member before returning
    family_members = [serialize_member(member) for member in family_members]

    return jsonify({"family_tree": family_members})

@app.route("/api/delete-member/<member_id>", methods=["DELETE"])
def delete_member(member_id):
    result = members_collection.delete_one({"_id": ObjectId(member_id)})

    if result.deleted_count == 1:
        return jsonify({"message": "Member deleted successfully"}), 200
    else:
        return jsonify({"error": "Member not found"}), 404


# ------------------------- MEMORIES -------------------------

@app.route("/api/add-memory", methods=["POST"])
def add_memory():
    try:
        data = request.get_json()
        memory = {
            "user_id": data["user_id"],
            "family_id": data["family_id"],
            "image_base64": data["image_base64"],
            "location": data["location"],
            "comment": data["comment"],
            "date": data["date"]
        }
        result = memories_collection.insert_one(memory)
        return jsonify({"message": "✅ Memory added", "id": str(result.inserted_id)}), 201
    except Exception as e:
        return jsonify({"message": f"❌ Error: {str(e)}"}), 500

@app.route("/api/get-memories", methods=["GET"])
def get_memories():
    user_id = request.args.get("user_id")
    print("Memories requested by user:", user_id)

    if not user_id:
        return jsonify({"message": "Missing user_id"}), 400

    memories = list(memories_collection.find({"user_id": user_id}))
    for mem in memories:
        mem["_id"] = str(mem["_id"])
    return jsonify({"memories": memories}), 200

@app.route("/api/delete-memory/<memory_id>", methods=["DELETE"])
def delete_memory(memory_id):
    try:
        result = memories_collection.delete_one({"_id": ObjectId(memory_id)})
        if result.deleted_count:
            return jsonify({"message": "✅ Memory deleted"}), 200
        return jsonify({"message": "❌ Memory not found"}), 404
    except Exception as e:
        return jsonify({"message": f"❌ Error: {str(e)}"}), 500

# ------------------------- ADMIN -------------------------

@app.route("/admin-login", methods=["POST"])
def admin_login():
    data = request.get_json()
    if data.get("username") == "admin" and data.get("password") == "admin123":
        return jsonify({"message": "✅ Admin login successful!"}), 200
    return jsonify({"message": "❌ Invalid admin credentials!"}), 401

# ------------------------- STATIC FILES -------------------------

@app.route("/uploads/<filename>")
def serve_file(filename):
    return send_from_directory(app.config["UPLOAD_FOLDER"], filename)

# ------------------------- MAIN -------------------------

if __name__ == "__main__":
    app.run(debug=True)
